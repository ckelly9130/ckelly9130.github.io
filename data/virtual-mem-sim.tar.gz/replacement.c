#include <stdio.h>
#include "vm.h"
#include "disk.h"
#include "dataobjects.h"

int fifoArray [MAX_FRAME] = {0};

int random()
{
		int next = rand() % MAX_PAGE;
		return next;
}

int fifo()
{
		int next = getFIFONext();
		if(next >= 0)
			return next;
		else
		{
			printf("FIFO FAIL!\n");
			exit(-1);
		}
}

int lru()
{
		int next = getLRUNext();
		if(next >= 0)
			return next;
		else
		{
			printf("LRU Fail!\n");
			exit(-1);
		}
}

int lfu()
{
		int next = getLFUNext();
		if(next >= 0)
			return next;
		else
		{
			printf("LFU FAIL!\n");
			exit(-1);
		}
}

int page_replacement()
{
		int frame;
		if(replacementPolicy == RANDOM)  frame = random(); 
		else if(replacementPolicy == FIFO)  frame = fifo();
		else if(replacementPolicy == LRU) frame = lru();
		else if(replacementPolicy == LFU) frame = lfu();

		return frame;
}

