typedef struct{
	int pages [MAX_PAGE];
}FIFOQUEUE;

typedef struct{
	struct NODE *next;
	struct NODE *prev;
	int pageVal;
}NODE;

typedef struct{
	NODE *first;
	NODE *last;
}LRULIST;

typedef struct{
	int priority;
	int pageVal;
	bool valid;
}MEMBER;

typedef struct{
	MEMBER pages[MAX_PAGE];
	int peak;
}LFUPRIORITYQUEUE;

void data_init();

void addPage(int page);


int getFIFONext();
int getLRUNext();
int getLFUNext();