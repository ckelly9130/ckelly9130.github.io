#include <stdio.h>
#include "vm.h"
#include "disk.h"
#include "pagetable.h"
#include "dataobjects.h"

PT pageTable;
Invert invert_table[MAX_FRAME];
int freeFrameCount = 0;

int hit_test(int pid, int pageNo, char type)
{
		if(invert_table[pageTable.entry[pid][pageNo].frameNo].page == pageNo && pageTable.entry[pid][pageNo].valid)
		{
			pageTable.stats.hitCount++;
			
			if(type == 'W')
				pageTable.entry[pid][pageNo].dirty = true;
			addPage(pageNo);
			return pageTable.entry[pid][pageNo].frameNo;
		}
		else
		{
			pageTable.stats.missCount++;
			return -1;
		}
}


int pagefault_handler(int pid, int pageNo, char type, bool *hit)
{
		addPage(pageNo);
		int frameNum;
		if(freeFrameCount < MAX_FRAME)
		{
			frameNum = freeFrameCount;
			freeFrameCount++;
			
			invert_table[frameNum].pid = pid;
			invert_table[frameNum].page = pageNo;
			
			pageTable.entry[pid][pageNo].frameNo = frameNum;
			pageTable.entry[pid][pageNo].valid = true;
			pageTable.entry[pid][pageNo].dirty = false;
			
			if(type== 'W')
				pageTable.entry[pid][pageNo].dirty = true;
			
			disk_read(frameNum,pid,pageNo);
			return frameNum;			
		}
		
		
		//Invert table full
		int pageNum; 
		int replacePID = -1;
		while(replacePID < 0)
		{
			pageNum = page_replacement();
			
			for(frameNum = 0; frameNum < MAX_FRAME; frameNum++)
			{
				//printf("Frame %d has page %d\ and victim page is %d\n", frameNum, invert_table[frameNum].page, pageNum);
				if(invert_table[frameNum].page == pageNum)
				{
					replacePID = invert_table[frameNum].pid;
					break;
				}
			}
		}
		
		pageTable.entry[replacePID][pageNum].valid = false;
		
		if(pageTable.entry[replacePID][pageNum].dirty)
		{
			disk_write(pageTable.entry[replacePID][pageNum].frameNo, replacePID, pageNum);
			pageTable.entry[replacePID][pageNum].dirty = false;
		}
		
		invert_table[frameNum].pid = pid;
		invert_table[frameNum].page = pageNo;
		
		disk_read(frameNum,pid,pageNo);
		
		pageTable.entry[pid][pageNo].frameNo = frameNum;
		pageTable.entry[pid][pageNo].valid = true;
		pageTable.entry[pid][pageNo].dirty = false;
		
		if(type == 'W')
			pageTable.entry[pid][pageNo].dirty = true;
		
		//printf("Frame %d has page %d\n", frameNum, invert_table[frameNum].page);
		return frameNum;
}

int MMU(int pid, int addr, char type, bool *hit)
{
		int frameNo;
		int pageNo = (addr >> 8);
		int offset = addr - (pageNo << 8);
		
		if(pageNo > MAX_PAGE) {
				printf("invalid page number (MAX_PAGE = 0x%x): pid %d, addr %x\n", MAX_PAGE, pid, addr);
				return -1;
		}
		if(pid > MAX_PID) {
				printf("invalid pid (MAX_PID = %d): pid %d, addr %x\n", MAX_PID, pid, addr);
				return -1;
		}

		
		// hit
		frameNo = hit_test(pid, pageNo, type);
		if(frameNo > -1) {
				*hit = true;
				return (frameNo << 8) + offset;
		}
		
		// pagefault
		*hit = false;
		frameNo = pagefault_handler(pid, pageNo, type, hit);
		return (frameNo << 8) + offset;
}

void pt_print_stats()
{
		int req = pageTable.stats.hitCount + pageTable.stats.missCount;
		int hit = pageTable.stats.hitCount;
		int miss = pageTable.stats.missCount;

		printf("Request: %d\n", req);
		printf("Hit: %d (%.2f%%)\n", hit, (float) hit*100 / (float)req);
		printf("Miss: %d (%.2f%%)\n", miss, (float)miss*100 / (float)req);
}

void pt_init()
{
		int i,j;

		pageTable.stats.hitCount = 0;
		pageTable.stats.missCount = 0;
		for(i = 0; i < MAX_PID; i++) {
				for(j = 0; j < MAX_PAGE; j++) {
						pageTable.entry[i][j].valid = false;
				}
		}
		
		data_init();
}