void disk_read(int frame, int pid, int page);
void disk_write(int frame, int pid, int page);

