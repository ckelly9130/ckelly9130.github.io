#include <stdio.h>
#include <stdlib.h>
#include "vm.h"
#include "dataobjects.h"

FIFOQUEUE fifoQueue;
LRULIST *lruList;
LFUPRIORITYQUEUE lfuQueue;

void data_init()
{
	int index;
	for(index = 0; index < MAX_PAGE; index++)
	{
		fifoQueue.pages[index] = -1;
		lfuQueue.pages[index].pageVal = -1;
		lfuQueue.pages[index].priority = 0;
		lfuQueue.pages[index].valid = false;
	}
	//printf("PRE_CALLOC: List:%d Node:%d - ", lruList, initNode);
	
	lruList = calloc(1,sizeof(LRULIST));
	//printf("List: %d - ",lruList);
	
	NODE *initNode = calloc(1,sizeof(NODE));
	//printf("Node: %d\n", initNode);
	
	initNode->pageVal = -1;
	initNode->next = initNode;
	initNode->prev = initNode;
	
	lruList->first = initNode;
	lruList->last = initNode;
	
	//printf("Node stats:\nNext: %d - Previous: %d - Page value: %d\n", initNode->next, initNode->prev, initNode->pageVal);
	//printf("List stats:\nFirst: %d - Last: %d\n", lruList->first, lruList->last);
	
	lfuQueue.peak = 0;
}

void addPage (int page)
{
	//FIFO
	int index;
	for(index = 0; index < MAX_PAGE; index++)
	{
		if(fifoQueue.pages[index] == page)
		{
			//printf("Index %d already had page %d\n", index,page);
			break;
		}
		else if(fifoQueue.pages[index] == -1)
		{
			//printf("Page %d is going into index %d.\n", page, index);
			fifoQueue.pages[index] = page;
			break;
		}
		
	}
	//for(index = 0; index < MAX_PAGE; index++){printf("%d. %d\n", index,fifoQueue.pages[index]);}
	//END FIFO
	
	//LRU
	if(lruList->first->pageVal == -1)
	{
		lruList->first->pageVal = page;
		//printf("Node stats:\nNext: %d - Previous: %d - Page value: %d\n", lruList->first->next, lruList->first->prev, lruList->first->pageVal);
	}
	else
	{
		NODE *existingNode = lruList->first;
		
		int currentPage = existingNode->pageVal;
		int lastPage = lruList->last->pageVal;
		
		while(currentPage != page && currentPage != lastPage)
		{
			//printf("Current page is %d. current node has page %d\n", page, currentPage);
			existingNode = existingNode->next;
			
			currentPage = existingNode->pageVal;
		}
		
		if(page == currentPage) //found page in list, move to front
		{
				if(page != lruList->first->pageVal)
				{
					NODE *prevNode = existingNode->prev;
					NODE *nextNode = existingNode->next;
					
					prevNode->next = existingNode->next;
					nextNode->prev = existingNode->prev;
					
					if(lruList->last->pageVal == existingNode->pageVal)
						lruList->last = existingNode->prev;
					
					lruList->first->prev = existingNode;
					lruList->last->next = existingNode;
					
					existingNode->next = lruList->first;
					existingNode->prev = lruList->last;
					
					lruList->first = existingNode;
				}
				//printf("Node stats:\nNext: %d - Previous: %d - Page value: %d\n", existingNode->next, existingNode->prev, existingNode->pageVal);
				
		}
		else //did not find page in list, add new node to front
		{
				//printf("Did not find page in list, allocating page %d new node - ", page);
				
				NODE *lruNode = calloc(1,sizeof(NODE));
				//printf("%d\n", lruNode);
				lruNode->pageVal = page;
				lruNode->next = lruList->first;
				lruNode->prev = lruList->last;
			
				lruList->first->prev = lruNode;
				lruList->last->next = lruNode;
				
				lruList->first = lruNode;
				//printf("New Node stats:\nNext: %d - Previous: %d - Page value: %d\n", lruNode->next, lruNode->prev, lruNode->pageVal);
		}
		
	} 
	/* printf("List stats:\nFirst: %d - Last: %d\n", lruList->first, lruList->last);
	printf("Node Stats:\n");
	
	NODE *start = lruList->first;
	int i = lruList->first->pageVal;
	int k = lruList->last->pageVal;
	int j = 0;
	while(i != k)
	{
		i = start->pageVal;
		//printf("Last page = %d - Current Page = %d\n", k, i);
		printf("Node: %d - next: %d - prev: %d - page:%d\n", j, start->next, start->prev, start->pageVal);
		start = start->next;
		//printf("Next page = %d\n", start->pageVal);
		i = start->pageVal;
		sleep(3);
		j++;
	}
	printf("Node: %d - next: %d - prev: %d - page:%d\n", j, start->next, start->prev, start->pageVal); */
	//END LRU
	
	//LFU
	//char *curQueue = "|"; 
	for(index = 0; index < MAX_PAGE; index++)
	{
			if(lfuQueue.pages[index].pageVal == page)
			{
				lfuQueue.pages[index].priority++;
				break;
			}
			else if(lfuQueue.pages[index].pageVal == -1)
			{
				lfuQueue.pages[index].pageVal = page;
				lfuQueue.pages[index].priority = 1;
				break;
			}
			//asprintf(&curQueue,"%s%d,%d,%d|", curQueue, lfuQueue.pages[index].pageVal, lfuQueue.pages[index].priority, lfuQueue.pages[index].valid);
	}
	//asprintf(&curQueue,"%s%d,%d|", curQueue, lfuQueue.pages[index].pageVal, lfuQueue.pages[index].priority);
	
	if(lfuQueue.peak < lfuQueue.pages[index].priority)
		lfuQueue.peak = lfuQueue.pages[index].priority;
	
	
	for(index = 0; index<MAX_FRAME; index++)
	{
		if(lfuQueue.pages[index].pageVal != -1)
			lfuQueue.pages[index].valid = true;
		else
			break;
	}
	//printf("Current queue - Peak: %d\n%s\n", lfuQueue.peak, curQueue);
	//END LFU
	
}

int getFIFONext ()
{
	int index;
	int next = fifoQueue.pages[0];
	for(index = 1; index <= MAX_PAGE; index++)
	{
		if(fifoQueue.pages[index] != -1)
			fifoQueue.pages[index-1] = fifoQueue.pages[index]; 
		else
		{
			fifoQueue.pages[index-1] = -1;
			break;
		}
	}
	return next;
}

int getLRUNext ()
{
	int next = lruList->last->pageVal;
	NODE *prevNode = lruList->last->prev;
	prevNode->next = lruList->first;
	lruList->last = prevNode;
	return next;
}

int getLFUNext ()
{
	int next = -1;
	int index;
	int comparator = lfuQueue.peak; 
	for(index = 0; index < MAX_PAGE; index++)
	{
		if(lfuQueue.pages[index].priority < comparator && lfuQueue.pages[index].pageVal != -1 && lfuQueue.pages[index].valid == true)
		{	
			//printf("Current priority less than compare int. Prev - %d ",comparator);
			comparator = lfuQueue.pages[index].priority;
			//printf("Current - %d\n", comparator);
		}
		
	}
	for(index = 0; index < MAX_PAGE; index++)
	{
		if(lfuQueue.pages[index].priority == comparator)
		{
			next = lfuQueue.pages[index].pageVal;
			//printf("Next victim = %d\n", next);
			
			int sort;
			for(sort = index+1; sort <= MAX_PAGE; sort++)
			{
					if(lfuQueue.pages[sort].pageVal != -1)
					{
						lfuQueue.pages[sort-1].pageVal = lfuQueue.pages[sort].pageVal;
						lfuQueue.pages[sort-1].priority = lfuQueue.pages[sort].priority;
						if((sort - 1) < MAX_FRAME)
							lfuQueue.pages[sort-1].valid = true;
						else
							lfuQueue.pages[sort-1].valid = false;
					}
					else
					{
						lfuQueue.pages[sort-1].pageVal = -1;
						lfuQueue.pages[sort-1].priority = 0;
						if((sort - 1) < MAX_FRAME)
							lfuQueue.pages[sort-1].valid = true;
						else
							lfuQueue.pages[sort-1].valid = false;
						break;
					}
			}
			break;
		}
	}
	//printf("Next victim = %d\n", next);
	return next;
}